#! /bin/bash
function mot-choisi() {

	read -p "choisis un mot pour ton ennemi ! ATTENTION DEFENSE DE REGARDER" mot
	echo "$mot"
} 
